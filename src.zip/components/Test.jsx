let a = '문자 a';
let b = [1, 2, 3, 4, 5, 6, 7];
let c = { test1: 'test1', test2: 'test2' };
let list = [
  '인천 을왕리 해수욕장',
  '송도 센트럴파크',
  '파주 프로방스 / 헤이리 마을',
  '춘천 소양강 스카이워크',
  '이천 별빛정원우주',
];

export { a, b, c, list };
