export default function List({ list, i, openModal}) {
  return (
    <li className="list">
      <p onClick={() => openModal(i)}>
        {i + 1} - {list}
      </p>
      <i className="fa-regular fa-trash-can"></i>
    </li>
  );
}
