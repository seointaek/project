import Contents from './Contents';
import Header from './Header';
import '../css/common.css';
import '../css/myreset.css';

export default function Main() {
  return (
    <>
      <Header />
      <Contents />
    </>
  );
}
