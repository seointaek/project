import { useState } from 'react';
import List from './List';
import NoList from './NoList';
import { list } from './Test';
import Modal from './Modal';

export default function Contents() {
  let [item] = useState(list);
  let [isActive, setIsActive] = useState(false);
  let [titleNum, settitleNum] = useState();
  let toggleModal = () => {
      setIsActive(!isActive);
  }
  let openModal = (i) => {
    setIsActive(true);
    settitleNum(i);
  }
  let closeModal = () => {
    setIsActive(false);
  }
  return (
    <div className="main">
      <div className="inputBox">
        <input type="text" placeholder="가고싶은 여행지를 등록하세요" />
        <button>add</button>
      </div>
      <button onClick={toggleModal}>모달 열기</button>
      <p className="count">
        <span>total</span>
        <strong>{item.length}</strong>
      </p>

      {list.length === 0 ? (
        <NoList />
      ) : (
        <ul className="listCon">
          {item.map((list, i) => {
            return <List list={list} i={i} openModal = {openModal}
           key={i} />;
          })}
        </ul>
      )}
      {isActive && (<Modal item={item} titleNum={titleNum}closeModal={closeModal}/>)}
    </div>
  );
}
