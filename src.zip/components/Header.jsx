export default function Header() {
  return (
    <header className="hd">
      <i className="fa-solid fa-rocket"></i>
      <span>가자</span>
      <span>여행</span>
    </header>
  );
}
