export default function Modal({item, closeModal, titleNum}){
    return(
      <>
      <div className='modal'>
        <p>여행지 이름{item[titleNum]}</p>
        <button onClick={closeModal}>닫기</button>
      </div>
      </>
    )
  }